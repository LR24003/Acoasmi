create view vista_reporte_comportamiento_pagos
            (id_asociado, asociado_nombre, id_prestamo, numero_prestamo, monto_concedido, saldo_capital_actual,
             estado_actual_credito, total_veces_en_mora, total_recargos_acumulados, maximo_dias_atraso_registrado,
             evaluacion_comportamiento_pago)
as
SELECT a.id_asociado,
       concat(a.apellidos, ', ', a.nombres)   AS asociado_nombre,
       pc.id_prestamo,
       pc.numero_prestamo,
       pc.monto_concedido,
       pc.saldo_capital_actual,
       pc.estado_prestamo                     AS estado_actual_credito,
       count(rma.id_mora_aplicada)            AS total_veces_en_mora,
       COALESCE(sum(rma.monto_recargo), 0.00) AS total_recargos_acumulados,
       COALESCE(max(rma.dias_atraso), 0)      AS maximo_dias_atraso_registrado,
       CASE
           WHEN pc.estado_prestamo::text = 'EN_MORA'::text THEN 'RIESGO ALTO'::text
           WHEN max(rma.dias_atraso) > 30 THEN 'RIESGO MEDIO (ATRASOS RECURRENTES)'::text
           WHEN count(rma.id_mora_aplicada) > 0 THEN 'REQUIERE OBSERVACION'::text
           ELSE 'ASOCIADO EXCELENTE / AL DIA'::text
           END                                AS evaluacion_comportamiento_pago
FROM prestamos_concedidos pc
         JOIN asociados a ON pc.id_asociado = a.id_asociado
         LEFT JOIN registro_mora_aplicada rma ON pc.id_prestamo = rma.id_prestamo
GROUP BY a.id_asociado, a.apellidos, a.nombres, pc.id_prestamo, pc.numero_prestamo, pc.monto_concedido,
         pc.saldo_capital_actual, pc.estado_prestamo;

alter table vista_reporte_comportamiento_pagos
    owner to postgres;

