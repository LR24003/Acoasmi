create function fn_verificar_periodo_contable() returns trigger
    language plpgsql
as
$$
DECLARE
    v_estado_periodo VARCHAR(15);
BEGIN
    -- Extraer el estado del periodo en base al año y mes de la partida que se intenta ingresar
    SELECT estado_periodo INTO v_estado_periodo
    FROM periodos_contables
    WHERE anio = EXTRACT(YEAR FROM NEW.fecha_partida) 
      AND mes = EXTRACT(MONTH FROM NEW.fecha_partida);

    IF v_estado_periodo = 'CERRADO' THEN
        RAISE EXCEPTION 'Restricción de Auditoría: No se pueden registrar transacciones en un periodo contable CERRADO.';
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_verificar_periodo_contable() owner to postgres;

