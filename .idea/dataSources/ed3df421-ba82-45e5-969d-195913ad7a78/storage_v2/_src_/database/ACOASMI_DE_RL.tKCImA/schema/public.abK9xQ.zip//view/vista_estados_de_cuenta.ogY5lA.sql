create view vista_estados_de_cuenta
            (id_asociado, documento_asociado, nombre_completo_asociado, numero_cuenta, tipo_cuenta, id_movimiento,
             fecha_movimiento, tipo_movimiento, descripcion_movimiento, ingresos, egresos, saldo_resultante)
as
SELECT a.id_asociado,
       a.numero_documento                   AS documento_asociado,
       concat(a.apellidos, ', ', a.nombres) AS nombre_completo_asociado,
       sc.numero_cuenta,
       sc.tipo_cuenta,
       sm.id_movimiento,
       sm.fecha_movimiento,
       sm.tipo_movimiento,
       sm.descripcion_movimiento,
       CASE
           WHEN sm.tipo_movimiento::text = ANY
                (ARRAY ['DEPOSITO_AHORRO'::character varying, 'APORTACION'::character varying, 'ABONO_PRESTAMO'::character varying]::text[])
               THEN sm.monto
           ELSE 0.00
           END                              AS ingresos,
       CASE
           WHEN sm.tipo_movimiento::text = 'RETIRO'::text THEN sm.monto
           ELSE 0.00
           END                              AS egresos,
       sm.saldo_resultante
FROM asociados a
         JOIN asociado_cuentas sc ON a.id_asociado = sc.id_asociado
         JOIN asociado_movimientos sm ON sc.id_cuenta = sm.id_cuenta;

alter table vista_estados_de_cuenta
    owner to postgres;

