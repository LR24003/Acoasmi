create function fn_validar_cuadracion_partida() returns trigger
    language plpgsql
as
$$
DECLARE
    v_total_debe NUMERIC(12,2);
    v_total_haber NUMERIC(12,2);
BEGIN
    -- Solo validar si la partida se va a consolidar o postear
    IF NEW.estado_partida = 'POSTEADA' THEN
        SELECT COALESCE(SUM(debe),0), COALESCE(SUM(haber),0) INTO v_total_debe, v_total_haber
        FROM partida_detalles
        WHERE id_partida = NEW.id_partida;

        IF v_total_debe <> v_total_haber THEN
            RAISE EXCEPTION 'Fallo de Auditoría: La partida contable número % no está cuadrada. (Debe: %, Haber: %)', 
                NEW.numero_partida, v_total_debe, v_total_haber;
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function fn_validar_cuadracion_partida() owner to postgres;

