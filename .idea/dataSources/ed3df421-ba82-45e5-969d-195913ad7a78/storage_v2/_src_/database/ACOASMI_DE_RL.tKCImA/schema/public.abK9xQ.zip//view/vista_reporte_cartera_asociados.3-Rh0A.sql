create view vista_reporte_cartera_asociados
            (id_asociado, numero_documento, nombre_completo, fecha_ingreso, fecha_retiro, estado,
             actividad_economica) as
SELECT a.id_asociado,
       a.numero_documento,
       concat(a.apellidos, ', ', a.nombres) AS nombre_completo,
       a.fecha_ingreso,
       a.fecha_retiro,
       a.estado,
       ae.descripcion                       AS actividad_economica
FROM asociados a
         LEFT JOIN actividades_economicas ae ON a.codigo_mh::text = ae.codigo_mh::text;

alter table vista_reporte_cartera_asociados
    owner to postgres;

