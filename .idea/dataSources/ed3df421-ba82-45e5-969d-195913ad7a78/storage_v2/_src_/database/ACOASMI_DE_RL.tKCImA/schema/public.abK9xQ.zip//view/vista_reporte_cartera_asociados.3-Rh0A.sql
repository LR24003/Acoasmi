create view vista_reporte_cartera_asociados
            (id_asociado, numero_documento, nombre_completo, fecha_ingreso, fecha_retiro, estado_asociado,
             actividad_economica) as
SELECT id_asociado,
       numero_documento,
       concat(apellidos, ', ', nombres)                                               AS nombre_completo,
       fecha_ingreso,
       fecha_retiro,
       estado_asociado,
       (SELECT actividades_economicas.descripcion
        FROM actividades_economicas
        WHERE actividades_economicas.id_actividad = asociados.id_actividad_economica) AS actividad_economica
FROM asociados;

alter table vista_reporte_cartera_asociados
    owner to postgres;

