create function fn_control_mora_critica() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Si los días de atraso superan los 90 días
    IF NEW.dias_atraso > 90 AND NEW.estado_mora = 'PENDIENTE' THEN
        -- 1. Marcar el préstamo en Mora Crítica si no lo está
        UPDATE prestamos_concedidos 
        SET estado_prestamo = 'EN_MORA'
        WHERE id_prestamo = NEW.id_prestamo;

        -- 2. Bloquear automáticamente al asociado para proteger el patrimonio de la asociación
        UPDATE asociados 
        SET estado_asociado = 'BLOQUEADO'
        WHERE id_asociado = (SELECT id_asociado FROM prestamos_concedidos WHERE id_prestamo = NEW.id_prestamo);
    END IF;
    RETURN NEW;
END;
$$;

alter function fn_control_mora_critica() owner to postgres;

