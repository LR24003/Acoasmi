create view vista_reporte_nuevas_afiliaciones
            (id_asociado, dui_asociado, nit_asociado, asociado_nombre, fecha_afiliacion, estado, actividad_economica,
             clasificacion_riesgo_lda, monto_maximo_mensual_esperado)
as
SELECT a.id_asociado,
       a.numero_documento                   AS dui_asociado,
       a.nit                                AS nit_asociado,
       concat(a.apellidos, ', ', a.nombres) AS asociado_nombre,
       a.fecha_ingreso                      AS fecha_afiliacion,
       a.estado,
       ae.descripcion                       AS actividad_economica,
       cpr.nivel_riesgo                     AS clasificacion_riesgo_lda,
       cpr.monto_maximo_mensual_esperado
FROM asociados a
         LEFT JOIN actividades_economicas ae ON a.id_actividad_economica = ae.id_actividad
         LEFT JOIN cumplimiento_perfil_riesgo cpr ON a.id_asociado = cpr.id_asociado;

alter table vista_reporte_nuevas_afiliaciones
    owner to postgres;

