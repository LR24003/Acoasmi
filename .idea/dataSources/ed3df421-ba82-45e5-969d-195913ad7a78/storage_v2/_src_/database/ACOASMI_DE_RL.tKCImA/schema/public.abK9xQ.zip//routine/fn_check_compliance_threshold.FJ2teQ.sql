create function fn_check_compliance_threshold() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.monto >= 10000.00 THEN
        INSERT INTO compliance_alertas (id_asociado, monto_transaccion, tipo_alerta, estado_alerta)
        SELECT 
            sc.id_asociado, 
            NEW.monto, 
            'EXCEDE_UMBRAL_EFECTIVO', 
            'PENDIENTE'
        FROM asociado_cuentas sc 
        WHERE sc.id_cuenta = NEW.id_cuenta;
    END IF;
    RETURN NEW;
END;
$$;

alter function fn_check_compliance_threshold() owner to postgres;

