create view vista_reporte_mora_asociados
            (id_asociado, numero_prestamo, monto_concedido, saldo_capital_actual, estado_prestamo, total_recargos_mora,
             maximo_dias_atraso)
as
SELECT p.id_asociado,
       p.numero_prestamo,
       p.monto_concedido,
       p.saldo_capital_actual,
       p.estado_prestamo,
       COALESCE(sum(m.monto_recargo), 0.00) AS total_recargos_mora,
       COALESCE(max(m.dias_atraso), 0)      AS maximo_dias_atraso
FROM prestamos_concedidos p
         LEFT JOIN registro_mora_aplicada m ON p.id_prestamo = m.id_prestamo AND m.estado_mora::text = 'PENDIENTE'::text
GROUP BY p.id_asociado, p.numero_prestamo, p.monto_concedido, p.saldo_capital_actual, p.estado_prestamo;

alter table vista_reporte_mora_asociados
    owner to postgres;

