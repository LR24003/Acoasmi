create function fn_procesar_movimiento_saldos() returns trigger
    language plpgsql
as
$$
BEGIN
    -- 1. Si es un DEPOSITO o APORTACION, aumenta el saldo de la cuenta del asociado
    IF NEW.tipo_movimiento IN ('DEPOSITO_AHORRO', 'APORTACION') THEN
        UPDATE asociado_cuentas 
        SET saldo_actual = saldo_actual + NEW.monto
        WHERE id_cuenta = NEW.id_cuenta;
        
    -- 2. Si es un RETIRO, disminuye el saldo de la cuenta del asociado
    ELSIF NEW.tipo_movimiento = 'RETIRO' THEN
        -- Validar primero si tiene fondos suficientes
        IF (SELECT saldo_actual FROM asociado_cuentas WHERE id_cuenta = NEW.id_cuenta) < NEW.monto THEN
            RAISE EXCEPTION 'Error de Auditoría: Fondos insuficientes para realizar el retiro.';
        END IF;

        UPDATE asociado_cuentas 
        SET saldo_actual = saldo_actual - NEW.monto
        WHERE id_cuenta = NEW.id_cuenta;

    -- 3. Si es un ABONO_PRESTAMO, disminuye el saldo de capital del crédito
    ELSIF NEW.tipo_movimiento = 'ABONO_PRESTAMO' THEN
        UPDATE prestamos_concedidos
        SET saldo_capital_actual = saldo_capital_actual - NEW.monto
        WHERE id_prestamo = NEW.id_prestamo;
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_procesar_movimiento_saldos() owner to postgres;

