create function fn_procesar_movimiento_saldos() returns trigger
    language plpgsql
as
$$
DECLARE
    v_saldo_actual NUMERIC(12,2);
    v_nuevo_saldo NUMERIC(12,2);
    v_estado_cuenta BOOLEAN;
BEGIN
    -- 1. Obtener saldo actual y estado de la cuenta aplicando bloqueo pesimista (FOR UPDATE)
    SELECT COALESCE(saldo_actual, 0.00), estado
    INTO v_saldo_actual, v_estado_cuenta
    FROM asociado_cuentas
    WHERE id_cuenta = NEW.id_cuenta
        FOR UPDATE;

    -- Validar existencia de la cuenta
    IF NOT FOUND THEN
        RAISE EXCEPTION 'La cuenta asociada con ID % no existe.', NEW.id_cuenta;
    END IF;

    -- Validar estado activo
    IF v_estado_cuenta IS NOT TRUE THEN
        RAISE EXCEPTION 'No se pueden realizar movimientos en una cuenta inactiva.';
    END IF;

    -- 2. Normalizar tipo de movimiento (Limpia espacios y pasa a mayúsculas)
    NEW.tipo_movimiento := UPPER(TRIM(NEW.tipo_movimiento));

    -- 3. Calcular el nuevo saldo según la naturaleza del movimiento
    -- SUMAN SALDO A LA CUENTA PASIVA (Ahorros / Aportaciones)
    IF NEW.tipo_movimiento IN ('DEPOSITO', 'APORTACION', 'ABONO') THEN
        v_nuevo_saldo := v_saldo_actual + NEW.monto;

        -- RESTAN SALDO DE LA CUENTA PASIVA
    ELSIF NEW.tipo_movimiento IN ('RETIRO', 'DEBITO', 'PAGO_PRESTAMO') THEN
        -- Validar saldo suficiente para operaciones que restan
        IF v_saldo_actual < NEW.monto THEN
            RAISE EXCEPTION 'Saldo insuficiente en la cuenta. Saldo disponible: %, Monto requerido: %', v_saldo_actual, NEW.monto;
        END IF;

        v_nuevo_saldo := v_saldo_actual - NEW.monto;

    ELSE
        RAISE EXCEPTION 'Tipo de movimiento no reconocido o no válido: %', NEW.tipo_movimiento;
    END IF;

    -- 4. Actualizar el saldo maestro en la tabla asociado_cuentas
    UPDATE asociado_cuentas
    SET saldo_actual = v_nuevo_saldo
    WHERE id_cuenta = NEW.id_cuenta;

    -- 5. Asignar el saldo calculado al nuevo registro de movimiento en asociado_movimientos
    NEW.saldo_resultante := v_nuevo_saldo;

    RETURN NEW;
END;
$$;

alter function fn_procesar_movimiento_saldos() owner to postgres;

