create view vista_reporte_flujo_cuentas_detallado
            (id_movimiento, id_cuenta, numero_cuenta, tipo_cuenta, id_asociado, asociado_nombre, fecha_movimiento,
             tipo_movimiento, descripcion_movimiento, monto_ingreso, monto_egreso, saldo_cuenta_post_movimiento,
             id_factura_referencia)
as
SELECT sm.id_movimiento,
       ac.id_cuenta,
       ac.numero_cuenta,
       ac.tipo_cuenta,
       a.id_asociado,
       concat(a.apellidos, ', ', a.nombres) AS asociado_nombre,
       sm.fecha_movimiento,
       sm.tipo_movimiento,
       sm.descripcion_movimiento,
       CASE
           WHEN sm.tipo_movimiento::text = ANY
                (ARRAY ['DEPOSITO_AHORRO'::character varying, 'APORTACION'::character varying, 'ABONO_PRESTAMO'::character varying]::text[])
               THEN sm.monto
           ELSE 0.00
           END                              AS monto_ingreso,
       CASE
           WHEN sm.tipo_movimiento::text = 'RETIRO'::text THEN sm.monto
           ELSE 0.00
           END                              AS monto_egreso,
       sm.saldo_resultante                  AS saldo_cuenta_post_movimiento,
       sm.id_factura_referencia
FROM asociado_movimientos sm
         JOIN asociado_cuentas ac ON sm.id_cuenta = ac.id_cuenta
         JOIN asociados a ON ac.id_asociado = a.id_asociado;

alter table vista_reporte_flujo_cuentas_detallado
    owner to postgres;

