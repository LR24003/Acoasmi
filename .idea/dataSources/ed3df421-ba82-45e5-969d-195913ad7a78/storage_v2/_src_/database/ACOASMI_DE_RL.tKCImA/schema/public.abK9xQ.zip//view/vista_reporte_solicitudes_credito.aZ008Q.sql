create view vista_reporte_solicitudes_credito
            (id_solicitud_linea, id_asociado, asociado_nombre, contacto_asociado, monto_solicitado, plazo_meses,
             linea_credito_solicitada, tasa_referencia, estado_solicitud, fecha_solicitud, fecha_ultima_actualizacion,
             observaciones_analista)
as
SELECT s.id_solicitud_linea,
       s.id_asociado,
       concat(a.apellidos, ', ', a.nombres) AS asociado_nombre,
       a.telefono                           AS contacto_asociado,
       s.monto_solicitado,
       s.plazo_meses,
       tp.nombre_producto                   AS linea_credito_solicitada,
       tp.tasa_interes_anual                AS tasa_referencia,
       s.estado_solicitud,
       s.fecha_solicitud,
       s.fecha_ultima_actualizacion,
       s.observaciones_analista
FROM solicitudes_credito_linea s
         JOIN asociados a ON s.id_asociado = a.id_asociado
         LEFT JOIN tasas_prestamos tp ON s.id_tasa_referencia = tp.id_tasa;

alter table vista_reporte_solicitudes_credito
    owner to postgres;

