create view vista_reporte_analisis_aportaciones
            (id_asociado, numero_cuenta, saldo_actual, tasa_interes_anual, fecha_apertura, estado_cuenta) as
SELECT id_asociado,
       numero_cuenta,
       saldo_actual,
       tasa_interes_anual,
       fecha_apertura,
       estado_cuenta
FROM asociado_cuentas
WHERE tipo_cuenta::text = 'APORTACIONES'::text;

alter table vista_reporte_analisis_aportaciones
    owner to postgres;

