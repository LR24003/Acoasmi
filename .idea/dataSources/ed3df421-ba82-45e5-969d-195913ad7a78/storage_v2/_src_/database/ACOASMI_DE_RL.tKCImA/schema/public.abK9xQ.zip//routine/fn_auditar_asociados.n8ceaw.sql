create function fn_auditar_asociados() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'UPDATE') THEN
        INSERT INTO auditoria_cambios_asociados (id_asociado, accion, datos_anteriores, datos_nuevos)
        VALUES (OLD.id_asociado, 'UPDATE', to_jsonb(OLD), to_jsonb(NEW));
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO auditoria_cambios_asociados (id_asociado, accion, datos_anteriores, datos_nuevos)
        VALUES (OLD.id_asociado, 'DELETE', to_jsonb(OLD), NULL);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;

alter function fn_auditar_asociados() owner to postgres;

